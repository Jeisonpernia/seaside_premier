# -*- coding: utf-8 -*-

from . import res_config
from . import crm_team
from . import product
from . import product_template
from . import sales_commission
from . import sale
from . import account_invoice
from . import account_payment
from . import sale_commission_level
from . import sale_commission_level_user
from . import sale_commission_level_percentage
from . import partner
from . import sale_make_invoice

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
